#include "lista.h"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

int main(){
  TNo *lista1 = NULL;
  TNo *lista2 = NULL;
  insereInicioListaSimples(&lista1, 4);
  return 0;
}


